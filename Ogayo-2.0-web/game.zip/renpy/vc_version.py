branch = 'fix'
nightly = False
official = True
version = '8.1.1.23060707'
version_name = 'Where No One Has Gone Before'
